.. _example-configuration:

Example configuration
=======

The latest working configuration of the author can be found at `GitHub <https://github.com/Fuco1/.emacs.d/blob/master/files/smartparens.el>`_. Before looking at it, have a look at the :ref:`default-configuration` for things already set up for you!
