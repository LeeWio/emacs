See the homepage for [installation and usage instructions](http://company-mode.github.io/).

File a bug report in [Issues](https://github.com/company-mode/company-mode/issues).

Ask a question or suggest a feature in [Discussions](https://github.com/company-mode/company-mode/discussions/).

See [Contributing](https://github.com/company-mode/company-mode/blob/master/CONTRIBUTING.md) on other ways to help out.

[![Build Status](https://github.com/company-mode/company-mode/actions/workflows/ci.yml/badge.svg)](https://github.com/company-mode/company-mode/actions/workflows/ci.yml)
[![GNU Emacs](https://img.shields.io/static/v1?logo=gnuemacs&logoColor=fafafa&label=Made%20for&message=GNU%20Emacs&color=7F5AB6&style=flat)](https://www.gnu.org/software/emacs/)
[![MELPA](https://melpa.org/packages/company-badge.svg)](https://melpa.org/#/company)
[![GNU ELPA](https://elpa.gnu.org/packages/company.svg)](https://elpa.gnu.org/packages/company.html)
[![GNU-devel ELPA](https://elpa.gnu.org/devel/company.svg)](https://elpa.gnu.org/devel/company.html)
