The icons in this subdirectory are taken from vscode-icons (https://github.com/vscode-icons/vscode-icons)
and are licensed under the Creative Commons - ShareAlike (CC BY-SA) license: https://creativecommons.org/licenses/by-sa/4.0/.
